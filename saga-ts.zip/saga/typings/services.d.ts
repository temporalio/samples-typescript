export interface DB {
    save(): Promise<string>
}
