import { Connection, WorkflowClient, WorkflowFailedError, CancelledFailure, WorkflowStartOptions } from '@temporalio/client';
import {
  openAccount as openAccountWorkflow,
} from './workflows';
import cuid from 'cuid';
import {Workflows} from "@typings/commands";
import OpenAccount = Workflows.OpenAccount;
async function run() {
  const connection = new Connection();
  const client = new WorkflowClient(connection.service);

  const openAccount:OpenAccount = {
    accountId: cuid(),
    address: {
      address1: '123 Mike Street',
      postalCode: '28625',
    },
    bankDetails: {
      accountNumber: cuid(),
      routingNumber: '1234555',
      accountType: 'Checking',
      personalOwner: {
        firstName: 'Mike',
        lastName: 'Nichols'
      }
    },
    bankId: 'USAA Savings and Loan',
    clientEmail: 'mike.nichols@temporal.io'
  }

  // Here is how we start our workflow
  const handle = await client.start(openAccountWorkflow, {
    taskQueue: 'demo',
    workflowId: 'saga-' + openAccount.accountId,
    args: [openAccount],
  });
  await handle.result()
}

run().catch((err) => {
  console.error('account failed to open', err);
  process.exit(1);
});
