import { Worker, NativeConnection, WorkerOptions,InjectedSinks } from '@temporalio/worker';
import {createClients} from "./clients";
import {createActivities} from "./activities";
import * as fs from 'fs';
import {LoggerSinks} from "./workflows";

// worker
async function run({
    local,
  address,
  namespace,
  clientCertPath,
  clientKeyPath,
  taskQueue,}: Env) {
  console.log('address',address, 'namespace',namespace,'clientCertPath',clientCertPath,'clientKeyPath',clientKeyPath)

  const sinks: InjectedSinks<LoggerSinks> = {
    logger: {
      info: {
        fn(workflowInfo, message) {
          console.log('workflow: ', workflowInfo.runId, 'message: ', message);
        },
        callDuringReplay: false, // The default
      },
      err: {
        fn(workflowInfo, message) {
          console.error('workflow: ', workflowInfo.runId, 'message: ', message);
        },
        callDuringReplay: false, // The default
      },
    },
  };


  // registrations
  const singletonClients = await createClients()
  const activities = createActivities(singletonClients) as any

  let opts:WorkerOptions = {
    workflowsPath: require.resolve('./workflows'),
    activities,
    taskQueue,
    sinks,
  }

  if(local != 'true') {
    let crtBytes = fs.readFileSync(clientCertPath)
    let keyBytes = fs.readFileSync(clientKeyPath)

    opts.connection = await NativeConnection.create({
        address,
        tls: {
          // See docs for other TLS options
          clientCertPair: {
            crt: crtBytes,
            key: keyBytes,
          },
        },
      });
    opts.namespace = namespace
  }
  const worker = await Worker.create(opts)

  await worker.run();
}

run(getEnv()).catch((err) => {
  console.error(err);
  process.exit(1);
});
// @@@SNIPEND

// Helpers for configuring the mTLS client and worker samples

function requiredEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new ReferenceError(`${name} environment variable is not defined`);
  }
  return value;
}

export interface Env {
  address: string;
  namespace: string;
  clientCertPath: string;
  clientKeyPath: string;
  serverNameOverride?: string;
  serverRootCACertificatePath?: string;
  taskQueue: string;
  local?: string;
}

export function getEnv(): Env {
  return {
    local: process.env.LOCAL,
    address: requiredEnv('TEMPORAL_ADDRESS'),
    namespace: requiredEnv('TEMPORAL_NAMESPACE'),
    clientCertPath: requiredEnv('TEMPORAL_CLIENT_CERT_PATH'),
    clientKeyPath: requiredEnv('TEMPORAL_CLIENT_KEY_PATH'),
    serverNameOverride: process.env.TEMPORAL_SERVER_NAME_OVERRIDE,
    serverRootCACertificatePath: process.env.TEMPORAL_SERVER_ROOT_CA_CERT_PATH,
    taskQueue: process.env.TEMPORAL_TASK_QUEUE || 'demo',
  };
}

