import { Context } from '@temporalio/activity';
import { CancelledFailure } from '@temporalio/common';
import {Accounts, Banking, BoundedContextClients, Clients, PostOffice} from "@typings/clients";
import {Commands} from "@typings/commands";

class ClientsClient implements Clients.Client {
    removeClient(params: Commands.RemoveClient): Promise<void> {
        console.log('REMOVING CLIENT', params)

        return Promise.resolve(undefined);
    }

    addClient(params: Commands.AddClient): Promise<void> {
        throw new Error(`OH NOES! Client ${params.accountId} failed`)

        console.log('ADDING CLIENT', params)

        return Promise.resolve(undefined);
    }

}
class AccountsClient implements Accounts.Client {
    createAccount(params: Commands.CreateAccount): Promise<void> {
        console.log('CREATING ACCOUNT', params)
        return Promise.resolve(undefined);
    }
}
class BankingClient implements Banking.Client {
    addBankAccount(params: Commands.AddBankAccount): Promise<void> {
        console.log('ADDING BANK ACCOUNT', params)
        throw new Error(`OH NOES! BankAccount ${params.accountId} failed`)
        // return Promise.resolve(undefined);
    }

    disconnectBankAccounts(params: Commands.DisconnectBankAccounts): Promise<void> {
        console.log('DISCONNECT BANK ACCOUNTS', params)

        return Promise.resolve(undefined);
    }
}
class PostOfficeClient implements PostOffice.Client {
    addAddress(params: Commands.AddPostalAddress): Promise<void> {

        console.log('ADDING ADDRESS', params)

        return Promise.resolve(undefined);
    }

    clearPostalAddresses(params: Commands.ClearPostalAddresses): Promise<void> {
        console.log('CLEARING ADDRESSES', params)

        return Promise.resolve(undefined);
    }

}
export const createClients = async ():Promise<BoundedContextClients> => {
    return {
        accounts: new AccountsClient(),
        banking: new BankingClient(),
        clients: new ClientsClient(),
        postOffice: new PostOfficeClient(),
    }
}

async function sample(sleepIntervalMs: number) : Promise<any>{
    try {
        // allow for resuming from heartbeat
        const startingPoint = Context.current().info.heartbeatDetails || 1;
        console.log('Starting activity at progress:', startingPoint);
        for (let progress = startingPoint; progress <= 100; ++progress) {
            // simple utility to sleep in activity for given interval or throw if Activity is cancelled
            // don't confuse with Workflow.sleep which is only used in Workflow functions!
            console.log('Progress:', progress);
            await Context.current().sleep(sleepIntervalMs);
            Context.current().heartbeat(progress);
        }
    } catch (err) {
        if (err instanceof CancelledFailure) {
            console.log('Fake progress activity cancelled');
            // Cleanup
        }
        throw err;
    }
}

