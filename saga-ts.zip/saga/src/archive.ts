//
// /*
// other experiments
//  */
// export async function openAccountAccumulating(params: OpenAccount): Promise<void> {
//
//     //logger.info(`OPEN ACCOUNT WORKFLOW: ${JSON.stringify(params,undefined, 2)}`)
//     let compensations: (Compensation)[] = []
//
//     try {
//         await createAccount({ accountId: params.accountId})
//     } catch( err ) {
//         // this is fatal so fails fast. no compensations are needed
//         throw err
//     }
//
//     // addClient
//     try {
//         await addClient({
//             accountId: params.accountId,
//             clientEmail: params.clientEmail,
//         })
//     } catch(err) {
//         compensations.push( {
//             message: prettyErrorMessage('add client failed', err),
//             fn: () => removeClient({ accountId: params.accountId})
//         })
//     }
//
//     // addBankAccount
//     try {
//         await addBankAccount({
//             accountId: params.accountId,
//             details: params.bankDetails,
//         })
//     } catch(err) {
//         compensations.push ({
//             message: prettyErrorMessage('add bank account failed', err),
//             fn: () => disconnectBankAccounts({ accountId: params.accountId})
//         })
//     }
//
//     // addAddress
//     try {
//         await addAddress({
//             accountId: params.accountId,
//             address: params.address,
//         })
//     } catch(err) {
//         compensations.push({
//             message: prettyErrorMessage('add postal address failed', err),
//             fn: () => clearPostalAddresses({ accountId: params.accountId})
//         })
//     }
//
//     // compensate if needed
//     // note that these are being done sequentially in order they appeared,
//     // but we could turn these into parallel without `await`ing
//     // eg `await Promise.allSettled([comp.fn,...])`
//     if(compensations.length > 0 ) {
//         logger.info('failures during account opening - compensating')
//         for (let comp of compensations) {
//             try {
//                 logger.err(comp.message)
//                 await comp.fn()
//             } catch(err) {
//
//                 logger.err(`failed to compensate: ${prettyErrorMessage('', err)}`)
//                 // swallow errors
//             }
//         }
//         throw new Error('account failed to open. compensations completed.')
//     }
// }
// // workflow implementations with calls being in parallel
// export async function openAccountParallel(params: OpenAccount): Promise<void> {
//
//     //logger.info(`OPEN ACCOUNT WORKFLOW: ${JSON.stringify(params,undefined, 2)}`)
//     let compensations: (Compensation)[] = []
//
//     try {
//         await createAccount({accountId: params.accountId})
//     } catch (err) {
//         // this is fatal so fails fast. no compensations are needed
//         throw err
//     }
//
//     try {
//         await Promise.all([
//                 parallelize(compensations, {
//                     fn: () => {
//                         return addClient({accountId: params.accountId, clientEmail: params.clientEmail})
//                     },
//                     comp: {
//                         message: 'add client failed',
//                         fn: () => removeClient({accountId: params.accountId})
//                     }
//                 }),
//                 parallelize(compensations, {
//                     fn: () => {
//                         return addBankAccount({accountId: params.accountId, details: params.bankDetails})
//                     },
//                     comp: {
//                         message: 'adding bank account failed',
//                         fn: () => disconnectBankAccounts({accountId: params.accountId})
//                     }
//                 }),
//                 parallelize(compensations, {
//                     fn: () => {
//                         return addAddress({accountId: params.accountId, address: params.address,})
//                     },
//                     comp: {
//                         message: 'adding address failed',
//                         fn: () => clearPostalAddresses({accountId: params.accountId})
//                     }
//                 }),
//             ]
//         )
//     } catch (err) {
//         logger.info(`PARALLEL FAILED ${err}`)
//         if (compensations.length > 0) {
//             logger.info('failures during account opening - compensating')
//             for (let comp of compensations) {
//                 try {
//                     logger.err(comp.message)
//                     await comp.fn()
//                 } catch (e) {
//                     let msg = comp.message
//                     if (e instanceof TemporalFailure) {
//                         msg = e.message
//                     }
//                     logger.err(`failed to compensate: ${prettyErrorMessage(msg, e)}`)
//                     // swallow errors
//                 }
//             }
//         }
//     }
// }
//
// async function parallelize(compensations: (Compensation)[], op: ParallelOp): Promise<void> {
//     try {
//         await op.fn()
//     } catch(err) {
//         if (op.comp && op.comp.fn) {
//             let msg = op.comp?.message || 'compensating'
//             compensations.push( {
//                 message: prettyErrorMessage(msg, err),
//                 fn: op.comp.fn,
//             })
//         }
//         throw err
//     }
// }