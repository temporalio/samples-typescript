import { proxyActivities, proxySinks, ApplicationFailure,TemporalFailure, ActivityCancellationType, Sinks } from '@temporalio/workflow';
import {createActivities} from './activities';
import { Workflows} from "@typings/commands";

import OpenAccount = Workflows.OpenAccount;

const defaultActivity = {
  startToCloseTimeout: '2s',
  scheduleToCloseTimeout: '3s',

}
const longRunningActivity = {
  startToCloseTimeout: '4s',
  scheduleToCloseTimeout: '8s',
  // heartbeatTimeout: '1s',
  // Don't send rejection to our Workflow until the Activity has confirmed cancellation
 // cancellationType: ActivityCancellationType.WAIT_CANCELLATION_COMPLETED,
}

// activityFunctions
const {
  addBankAccount
} = proxyActivities<ReturnType<typeof createActivities>>(longRunningActivity)

const {
  createAccount,
  addClient,
  removeClient,
  addAddress,
  clearPostalAddresses,
  disconnectBankAccounts
} = proxyActivities<ReturnType<typeof createActivities>>(defaultActivity)

// utils
const { logger } = proxySinks<LoggerSinks>();

// interfaces
export interface LoggerSinks extends Sinks {
  logger: {
    info(message: string): void;
    err(message: string): void;
  };
}

interface ParallelOp {
  fn: () => Promise<void>
  comp?: Compensation
}
interface Compensation {
  message: string
  fn: () => Promise<void>
}


// workflow implementations
// sequential executions
export async function openAccount(params: OpenAccount): Promise<void> {

  //logger.info(`OPEN ACCOUNT WORKFLOW: ${JSON.stringify(params,undefined, 2)}`)
  let compensations: (Compensation)[] = []

  try {
    await createAccount({ accountId: params.accountId})
  } catch( err ) {
    // this is fatal so fails fast. no compensations are needed
    throw err
  }

  try {
    // addAddress
    await addAddress({
      accountId: params.accountId,
      address: params.address,
    })
    compensations.push({
      message: prettyErrorMessage('add postal address failed'),
      fn: () => clearPostalAddresses({ accountId: params.accountId})
    })

    // addClient
    await addClient({
      accountId: params.accountId,
      clientEmail: params.clientEmail,
    })
    compensations.push( {
      message: prettyErrorMessage('add client failed'),
      fn: () => removeClient({ accountId: params.accountId})
    })

    // addBankAccount
    await addBankAccount({
      accountId: params.accountId,
      details: params.bankDetails,
    })
    compensations.push ({
      message: prettyErrorMessage('add bank account failed'),
      fn: () => disconnectBankAccounts({ accountId: params.accountId})
    })
  } catch(err) {
    await compensate(compensations)
    throw err
  }
}

async function compensate(compensations: (Compensation)[] = []) {
  console.log('compensating', compensations.length)
  if(compensations.length > 0 ) {
    logger.info('failures during account opening - compensating')
    for (let comp of compensations) {
      try {
        logger.err(comp.message)
        await comp.fn()
      } catch(err) {

        logger.err(`failed to compensate: ${prettyErrorMessage('', err)}`)
        // swallow errors
      }
    }
  }
}


function prettyErrorMessage(message:string, err?:any) {
  let errMessage = ''
  if (err && err instanceof TemporalFailure) {
    errMessage = `${err.cause?.message}`
  }
  if (err && err instanceof Error) errMessage = err.message
  return `${message}: ${errMessage}`
}
